<?php
/**
*
*/
class Layanan extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Layanan_model');

	}

	function index()
	{
		//print_r($this->Karyawan_model->ambil_data());
		$data['layanan']=$this->Layanan_model->ambil_data();
		$this->load->view('Layanan/layanan_list',$data);
	}

	function tambah(){
		$data=array(
			'nama_layanan'=>set_value('nama_layanan'),
			'harga'=>set_value('harga'),
			'id_layanan'=>set_value('id_layanan'),
			'button'=>'Tambah',
			'action'=>site_url('Layanan/tambah_aksi'),
			);

		$this->load->view('Layanan/layanan_form',$data);
	}

	function tambah_aksi(){
		$data=array(
			'nama_layanan'=>$this->input->post('nama_layanan'),
			'harga'=>$this->input->post('harga'),
			);
		$this->Layanan_model->tambah_data($data);
		redirect(site_url('Layanan'));
	}
	function delete($id){
		$this->Layanan_model->hapus_data($id);
		redirect(site_url('Layanan'));
	}
	function edit($id){
		$brg=$this->Layanan_model->ambil_data_id($id);
		$data=array(
			'nama_layanan'	=>set_value('nama_layanan',$brg->nama_layanan),
			'harga'	=>set_value('harga',$brg->harga),
			'id_layanan' =>set_value('id_layanan',$brg->id_layanan),
			'button'	=>'Edit',
			'action'	=>site_url('Layanan/edit_aksi'),
			);
		$this->load->view('Layanan/layanan_form',$data);
	}

	function edit_aksi(){
		$data=array(
			'nama_layanan'=>$this->input->post('nama_layanan'),
			'harga'=>$this->input->post('harga'),
			);
		$id=$this->input->post('id_layanan');
		$this->Layanan_model->edit_data($id,$data);
		redirect(site_url('Layanan'));
	}


}
 ?>
