<?php
/**
*
*/
class Transaksi extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Transaksi_model');
		$this->load->model('Karyawan_model');
		$this->load->model('Customer_model');
		$this->load->model('Layanan_model');

		/*if($this->session->userdata('logged_in'))
		{
		}
		else
		{
			redirect('login', 'refresh');
		}*/
	}

	function index()
	{
		$session_data = $this->session->userdata('logged_in');
		$data2['username'] = $session_data['username'];
		$data['Transaksi'] = $this->Transaksi_model->ambil_data();
		$this->load->view('Transaksi/transaksi_list',$data);
		//$this->output->enable_profiler(TRUE);
 		//$data['mahasiswa2'] = $this->Mahasiswa_model->ambil_data();
		//$this->load->view('Mahasiswa/mahasiswa_list',$data);
	}

	function tambah_data()
	{
		$data = array(
			'karyawan' => $this->Karyawan_model->ambil_data(),
			'id_transaksi' => set_value('id_transaksi'),
			'customer' => $this->Customer_model->ambil_data(),
			'layanan' => $this->Layanan_model->ambil_data(),
			'tgl_masuk' => set_value('tgl_masuk'),
			'waktu' => set_value('waktu'),
			//'jenis_laundry' => set_value('jenis_laundry'),
			'jumlah' => set_value('jumlah'),
			'harga' => set_value('harga'),
			'button' => 'Simpan',
			'action' => site_url('Transaksi/tambah_data_aksi'),
			);
		$this->load->view('Transaksi/transaksi_form', $data);
	}

	function tambah_data_aksi()
	{
		$data = array(

			'id_transaksi' => $this->input->post('id_transaksi'),
			'id_pegawai' => $this->input->post('id_pegawai'),
			'id_layanan' => $this->input->post('id_layanan'),
		//	'id_barang' => $this->input->post('id_barang'),
			'tgl_masuk' => $this->input->post('tgl_masuk'),
			'waktu' => $this->input->post('waktu'),
			//'jenis_laundry' => $this->input->post('jenis_laundry'),
			'jumlah' => $this->input->post('jumlah'),
			'harga' => $this->input->post('harga'),
			);
		$this->Transaksi_model->tambah_data($data);
		redirect(site_url('Transaksi'));
	}

	function delete($id)
	{
		$this->Transaksi_model->hapus_data($id);
		redirect(site_url('Transaksi'));
	}

	function edit($id)
	{
		$transaksi=($this->Transaksi_model->ambil_data_id($id));

		//Mencari Indeks Customer
		$Customer=($this->Customer_model->ambil_data_id($transaksi->id_customer));
		$arrCustomer = $this->Customer_model->ambil_data();
		$indexCustomer=0;
		foreach ($arrCustomer as $key => $value) {
			if($value->nama_customer == $Customer->nama_customer){
				break;
			}
			else {
				$indexCustomer++;
			}
		}

		//Mencari Indeks Pegawai

		$Karyawan=($this->Karyawan_model->ambil_data_id($transaksi->id_pegawai));
		$arrKaryawan = $this->Karyawan_model->ambil_data();
		$indexKaryawan=0;
		foreach ($arrKaryawan as $key => $value) {
			if($value->nama_pegawai == $Karyawan->nama_pegawai){
				break;
			}
			else{
				$indexKaryawan++;
			}
		}

		//Mencari Indeks Treatment
		$Barang=($this->Barang_model->ambil_data_id($transaksi->id_barang));
		$arrBarang = $this->Barang_model->ambil_data();
		$indexBarang=0;
		foreach ($arrBarang as $key => $value) {
			if($value->nama_barang == $Barang->nama_barang){
				break;
			}
			else{
				$indexBarang++;
			}
		}

		$data = array(
			'karyawan' => $this->Karyawan_model->ambil_data(),
			'id_laundry' => set_value('id_laundry',$transaksi->id_laundry),
			'customer' => $this->Customer_model->ambil_data(),
			'barang' => $this->Barang_model->ambil_data(),
			'tgl_masuk' => set_value('tgl_masuk',$transaksi->id_laundry),
			'waktu' => set_value('waktu',$transaksi->waktu),
			'jenis_laundry' => set_value('jenis_laundry',$transaksi->jenis_laundry),
			'jumlah' => set_value('jumlah',$transaksi->jumlah),
			'harga' => set_value('harga',$transaksi->harga),
			'button' => 'Edit',
			'action' => site_url('Transaksi/edit_aksi')
			);
		$this->load->view('Transaksi/transaksi_form', $data);
	}

	function edit_aksi()
	{
		$data = array(
			'id_pegawai' => $this->input->post('id_pegawai'),
			'id_customer' => $this->input->post('id_customer'),
			'id_barang' => $this->input->post('id_barang'),
			'tgl_masuk' => $this->input->post('tgl_masuk'),
			'waktu' => $this->input->post('waktu'),
			'jenis_laundry' => $this->input->post('jenis_laundry'),
			'tgl_masuk' => $this->input->post('tgl_masuk'),
			'jumlah' => $this->input->post('jumlah'),
			'harga' => $this->input->post('harga'),
			);
		$id_laundry = $this->input->post('id_laundry');
		$this->Transaksi_model->edit_data($id_laundry,$data);
		redirect(site_url('transaksi'));
	}

}
?>
