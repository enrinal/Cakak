<?php
/**
 *
 */
 class Transaksi_model extends CI_Model
 {
 	public $nama_table = 'transaksi';
	public $id = 'id_transaksi';
 	public $order = 'ASC';

 	function __construct()
 	{
 		parent::__construct();
 	}

 	//untuk mengambil data seluruh mahasiswa
 	function ambil_data()
 	{
 		//$this->db->distinct();
 		$this->db->select('*');
 		$this->db->from('transaksi');
 		// $this->db->join('customer c', 'c.id_customer = la.id_customer');
 		// $this->db->join('karyawan kar', 'kar.id_pegawai = la.id_pegawai');
 		// $this->db->join('barang bar', 'bar.id_barang = la.id_barang');
    $this->db->join('customer', 'transaksi.id_customer = customer.id_customer');
    $this->db->join('karyawan','transaksi.id_pegawai = karyawan.id_pegawai');
    $this->db->join('layanan', 'transaksi.id_layanan = layanan.id_layanan');
    //$this->db->order_by('id_transaksi','DESC')
    // $this->db->join 'customer' on 'transaksi.id_customer = customer.id_customer';
    // $this->db->join 'karyawan'o'transaksi.id_pegawai = karyawan.id_pegawai');
    // $this->db->join 'layanan' on 'transaksi.id_layanan = layanan.id_layanan';
 		return $this->db->get()->result();
 		// $data['peminjaman'] = $this->db->order_by($this->id, $this->order);
 		// return $this->db->get($this->nama_table)->result();
    //$sql  = "SELECT * from transaksi join customer on transaksi.id_customer=customer.id_customer join karyawan on transaksi.id_pegawai=karyawan.id_pegawai join layanan on transaksi.id_layanan=layanan.id_layanan";
    //return $this->db->query($sql);
  //  return $this->db->get($this->nama_table)->result();
 	}

 	function ambil_data_id($id)
 	{
 		$this->db->where($this->id,$id);
 		return $this->db->get($this->nama_table)->row();
 	}

 	function tambah_data($data)
 	{
 		return $this->db->insert($this->nama_table, $data);
 	}

 	function hapus_data($id)
 	{
 		$this->db->where($this->id, $id);
 		$this->db->delete($this->nama_table);
 	}

 	function edit_data($id_laundry,$data)
 	{
 		$this->db->where($this->id, $id_laundry);
 		$this->db->update($this->nama_table,$data);
 	}
 }
 ?>
