	<?php $this->load->view('templates/header') ?>
	<form action="<?php echo $action; ?>" method="POST">
	<div class="form-group">
		<label>Nama Layanan</label>
		<input type="text" placeholder="Masukkan Nama Layanan" value="<?php echo $nama_layanan; ?>" class="form-control" name="nama_layanan">
	</div>
	<div class="form-group">
		<label>Harga</label>
		<input type="text" placeholder="Masukkan Ukuran" value="<?php echo $harga; ?>" class="form-control" name="harga">
	</div>

	<input type="hidden" name="id_layanan" value="<?php echo $id_layanan; ?>">
	<button type="submit" class="btn btn-primary"><?php echo $button; ?></button>

	<a href="<?php echo site_url('Layanan')?>" class="btn btn-default">Cancel</a>

	</form>

	<?php $this->load->view('templates/footer') ?>
